#ifndef FUNCS_H
#define FUNCS_H

void menu_item_1(void); // Ohm's Law Calculator
void menu_item_2(void); // Placeholder
void menu_item_3(void); // Placeholder
void menu_item_4(void); // Placeholder
void menu_item_5(void); // Exit
void menu_item_6(void); // Tank game

#endif
